#include<bits/stdc++.h>
using namespace std;
int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    string s;
    map<string,string>m;
    map<string,string>::iterator i;

    m["HELLO"]="ENGLISH";
    m["HOLA"]="SPANISH";
    m["HALLO"]="GERMAN";
    m["BONJOUR"]="FRENCH";
    m["CIAO"]="ITALIAN";
    m["ZDRAVSTVUJTE"]="RUSSIAN";

    int j=0;
    while(1)
    {
       int k=0;
        cin>>s;

        if(s == "#") break;

        cout<<"Case "<<++j<<": ";
       transform(s.begin(), s.end(), s.begin(), ::toupper);
        for(i=m.begin(); i!=m.end(); ++i)
        {
            if(s == i->first){
               k=1; cout<<i->second<<endl;break;
            }
        }
        if(k==0) {cout<<"UNKNOWN"<<endl;}

    }
    return 0;
}
