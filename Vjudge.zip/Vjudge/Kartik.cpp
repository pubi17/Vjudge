#include <bits/stdc++.h>
using namespace std;

void solve(string str)
{

    int total =0,i=0,j,ln=0,sum=0,r=0;
    int c=0;
    istringstream ss(str);

    do {
string word;
        ss >> word;

    ln = word.size();
    sum += ln;
    c++;

    } while (ss);

 r = sum/(c-1);

    cout<<r<<".0"<<endl;

}


int main()
{
    char str[100],str1[100];
    gets(str1);
    int l=0,i,j;
     l = strlen(str1);
    if(str1[0]==' ') cout<<"0.0"<<endl;
    else{
    for( j=0,i=0; i<l ;++i)
    {
        if(isdigit(str1[i]) || str1[i]=='.' || str1[i]==','||str1[i]=='!') continue;
        else
        str[j++]=str1[i];

    }
    str[j]='\0';

    solve(str);
    }
    return 0;
}
