#include<bits/stdc++.h>
using namespace std;
typedef pair<string,int>pi;
int main()
{
    ios::sync_with_stdio(0);
   int t,n,mid;
   string st;
   vector<pi>v;
   cin>>t;
   deque<int>dq;
   for(int i=0;i<t;i++){
     cin>>st>>n;
     v.push_back(pi(st,n));
        if(v[i].first=="push_back")
        dq.push_back(v[i].second);
        if(v[i].first=="push_front")
        dq.push_front(v[i].second);
        std::deque<int>::iterator it =dq.begin();
        it=it+(dq.size()+1)/2;
        if(v[i].first=="push_middle")
        dq.insert (it,v[i].second);
        if(v[i].first=="get")
        cout<<dq[v[i].second]<<endl;
   }
    v.clear();
    dq.clear();

return 0;
}

