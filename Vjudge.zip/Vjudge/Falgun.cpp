#include <bits/stdc++.h>
using namespace std;

int main(){

int n; cin >> n;
int a,b;
string s;
map<pair<int,int>,string> mp;
while(n--){
cin>>a>>b>>s;
mp[make_pair(a,b)]=s;
}
int t; cin >> t;
while(t--){
cin >> a >> b;
cout<<mp[make_pair(a,b)]<<endl;
}
	return 0;
}
