
#include<bits/stdc++.h>
using namespace std;
int main()
{
    double n,b,p,min,max;
    ios::sync_with_stdio(0);
    cin>>n;
    while(n--)
    {
       cin>>b>>p;
       double bpm=(60*b)/p;
       //cout<<fixed<<steprecision(4)<<bpm-
       min=bpm-(bpm/b);
       max=bpm-min;
       cout<<fixed<<setprecision(4)<<min<<" "<<bpm<<" "<<bpm+max<<endl;

    }
    return 0;
}
