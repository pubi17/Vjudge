#include<bits/stdc++.h>
using namespace std;
int main()
{
    double r,m,c,a,a2;

    ios::sync_with_stdio(0);
    while(1)
    {
    cin>>r>>m>>c;

    if(r==0&&m==0&&c==0) break;

    a=3.141592654*(r*r);

    cout<<showpoint;
    cout<<setprecision(10);

    cout<<a<<" ";

    double d=2.00*r;
        a2=(d*d*c)/m;


        cout<<a2<<endl;
    }
   return 0;
}
